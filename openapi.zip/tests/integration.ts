async function runTests() {
    console.log("Iniciando pruebas de integración...");
    
    console.log("Pruebas finalizadas con éxito.");
}